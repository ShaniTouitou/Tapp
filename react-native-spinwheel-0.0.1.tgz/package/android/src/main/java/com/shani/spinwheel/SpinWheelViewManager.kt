package com.shani.spinwheel

import android.view.View
import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.annotations.ReactProp

class SpinWheelViewManager : SimpleViewManager<View>() {

    override fun getName(): String = "SpinWheelView"

    override fun createViewInstance(reactContext: ThemedReactContext): View {
        return SpinWheelView(reactContext)
    }

    @ReactProp(name = "configUrl")
    fun setConfigUrl(view: View, url: String?) {
        val spinWheelView = view as? SpinWheelView ?: return
        if (!url.isNullOrBlank()) {
            spinWheelView.setConfigUrl(url)
            spinWheelView.loadConfig()
        }
    }
}