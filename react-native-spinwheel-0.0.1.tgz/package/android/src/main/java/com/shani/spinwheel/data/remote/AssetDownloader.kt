package com.shani.spinwheel.data.remote

import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

class AssetDownloader(
    private val client: OkHttpClient
) {
    fun downloadToFile(url: String, outputFile: File): File? {
        val resolvedUrl = resolveGoogleDriveUrl(url)
        val request = Request.Builder()
            .url(resolvedUrl)
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            Log.d("AssetDownloader", "URL: $resolvedUrl")
            Log.d("AssetDownloader", "Code: ${response.code}")
            Log.d("AssetDownloader", "Content-Type: ${response.header("Content-Type")}")

            if (!response.isSuccessful) return null

            val body = response.body ?: return null
            val contentType = response.header("Content-Type") ?: ""

            // Google Drive returns HTML when it shows a virus/size warning page
            if (contentType.contains("text/html")) {
                Log.w("AssetDownloader", "Got HTML instead of image — trying Drive confirm URL")
                return downloadGoogleDriveConfirm(resolvedUrl, outputFile)
            }

            outputFile.outputStream().use { output ->
                body.byteStream().copyTo(output)
            }

            Log.d("AssetDownloader", "Saved ${outputFile.name}, size=${outputFile.length()}")
            return outputFile
        }
    }

    private fun resolveGoogleDriveUrl(url: String): String {
        // Convert share/view URLs to direct download
        val fileIdRegex = Regex("(?:/d/|id=)([a-zA-Z0-9_-]{10,})")
        val match = fileIdRegex.find(url)
        return if (match != null) {
            "https://drive.google.com/uc?export=download&id=${match.groupValues[1]}"
        } else url
    }

    private fun downloadGoogleDriveConfirm(url: String, outputFile: File): File? {
        // For large files, Drive requires a confirm token — extract it from the warning page
        val pageRequest = Request.Builder().url(url).build()
        val confirmToken = client.newCall(pageRequest).execute().use { response ->
            response.body?.string()
                ?.let { Regex("confirm=([a-zA-Z0-9_-]+)").find(it)?.groupValues?.get(1) }
        } ?: return null

        val confirmUrl = "$url&confirm=$confirmToken"
        val request = Request.Builder().url(confirmUrl).build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val body = response.body ?: return null
            outputFile.outputStream().use { body.byteStream().copyTo(it) }
            Log.d("AssetDownloader", "Saved via confirm: ${outputFile.name}, size=${outputFile.length()}")
            return outputFile
        }
    }
}