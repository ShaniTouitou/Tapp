package com.shani.spinwheel.presentation.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.shani.spinwheel.data.repository.AssetRepository
import kotlinx.coroutines.launch
import kotlin.random.Random
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.CompositingStrategy

private fun urlToFileName(url: String, prefix: String): String {
    val hash = url.hashCode().toLong() and 0xFFFFFFFFL
    return "${prefix}_${hash}.png"
}

@Composable
fun SpinWheelRemoteScreen(
    backgroundUrl: String,
    wheelUrl: String,
    frameUrl: String,
    spinButtonUrl: String,
    minimumSpins: Int,
    maximumSpins: Int,
    durationMillis: Int,
    assetRepository: AssetRepository
) {
    val rotation = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var isSpinning by remember { mutableStateOf(false) }

    val bgState by rememberCachedImageFile(backgroundUrl, urlToFileName(backgroundUrl, "bg"), assetRepository)
    val wheelState by rememberCachedImageFile(wheelUrl, urlToFileName(wheelUrl, "wheel"), assetRepository)
    val frameState by rememberCachedImageFile(frameUrl, urlToFileName(frameUrl, "wheel_frame"), assetRepository)
    val spinState by rememberCachedImageFile(spinButtonUrl, urlToFileName(spinButtonUrl, "wheel_spin"), assetRepository)

    fun randomTargetRotation(): Float {
        val spins = Random.nextInt(minimumSpins, maximumSpins + 1)
        val extraDegrees = Random.nextInt(0, 360)
        return rotation.value + spins * 360f + extraDegrees
    }

    val allLoaded = bgState is AssetLoadState.Success &&
            wheelState is AssetLoadState.Success &&
            frameState is AssetLoadState.Success &&
            spinState is AssetLoadState.Success

    val anyError = listOf(bgState, wheelState, frameState, spinState)
        .filterIsInstance<AssetLoadState.Error>()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        if (allLoaded) {
            val bgFile = (bgState as AssetLoadState.Success).file
            val wheelFile = (wheelState as AssetLoadState.Success).file
            val frameFile = (frameState as AssetLoadState.Success).file
            val spinFile = (spinState as AssetLoadState.Success).file

            BitmapFactory.decodeFile(bgFile.absolutePath)?.let { bitmap ->
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Background",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }

            BitmapFactory.decodeFile(wheelFile.absolutePath)?.let { bitmap ->
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Wheel",
                    modifier = Modifier
                        .size(250.dp)
                        .rotate(rotation.value)
                )
            }

            BitmapFactory.decodeFile(frameFile.absolutePath)?.let { bitmap ->
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Frame",
                    modifier = Modifier.size(300.dp)
                )
            }

            BitmapFactory.decodeFile(spinFile.absolutePath)?.let { bitmap ->
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Spin Button",
                    modifier = Modifier
                        .size(100.dp)
                        .graphicsLayer {
                            alpha = 0.99f
                            compositingStrategy = CompositingStrategy.Offscreen
                        }
                        .pointerInput(isSpinning) {
                            detectTapGestures {
                                if (!isSpinning) {
                                    scope.launch {
                                        isSpinning = true
                                        rotation.animateTo(
                                            targetValue = randomTargetRotation(),
                                            animationSpec = tween(durationMillis)
                                        )
                                        isSpinning = false
                                    }
                                }
                            }
                        }
                )
            }
        } else if (anyError.isNotEmpty()) {
            Text(text = anyError.joinToString("\n") { it.message })
        } else {
            Text("Loading assets...")
        }
    }
}